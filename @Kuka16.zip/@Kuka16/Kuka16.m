classdef Kuka16 < RobotBaseClass
    %% Class is called Kuka16

    properties(Access = public)              
        plyFileNameStem = 'Kuka16';
    end
    
    methods
%% Define robot Function 
        
function self = Kuka16(baseTr,useTool,toolFilename)  
   
    % baseTr (base transformation matrix 4x4, useTool (use a tool boolean),
    % and toolFilename (name of file for the tool).

             if nargin < 1			% Checking if baseTr is used
				baseTr = eye(4);				
             end

             if nargin < 3          % Check if toolFilename and useTool are used
                 if nargin == 2
                     error('If you set useTool you must pass in the toolFilename as well');
                 elseif nargin == 0 % Nothing passed
                     baseTr = transl(0,0,0);  
                 end             
             else % All passed in 
                 self.useTool = useTool;
                 toolTrData = load(Kuka16Link6,'.ply');        % Using tool properties
                 self.toolTr = toolTrData.tool;
                 self.toolFilename = [Kuka16Link6,'.ply'];
             end
          
            self.CreateModel();                                     % Creating the robot model
			self.model.base = self.model.base.T * baseTr;        % Performing needed transformations
            self.useTool = true;
            self.toolFilename = 'Kuka16Link6.ply';
            self.model.tool = self.toolTr;
            self.PlotAndColourRobot();

            drawnow     % Updating the plot
        end


%% Create the robot model
        function CreateModel(self)   
            % CreateModel function to create the model of the robot
      
            % Robot links and parameters defined 
            link(1) = Link('d',0.675,'a',0.260,'alpha',-pi/2,'qlim', deg2rad([-360 360]), 'offset',0); 
            link(2) = Link('d',0,'a',0.680,'alpha',0,'qlim', deg2rad([-360 360]), 'offset',0); 
            link(3) = Link('d',0,'a',0,'alpha',pi/2,'qlim', deg2rad([-360 360]), 'offset',0); 
            link(4) = Link('d',-0.670,'a',0,'alpha',-pi/2,'qlim', deg2rad([-360 360]), 'offset',0);
            link(5) = Link('d',0,'a',0,'alpha',pi/2,'qlim', deg2rad([-360 360]), 'offset',0); 
            link(6) = Link('d',-0.158,'a',0,'alpha',pi,'qlim', deg2rad([-360 360]), 'offset',0); 
            link(7) = Link('d',0,'a',-0.24365,'alpha',0,'qlim', deg2rad([-360 360]), 'offset',0);
            



            % Incorporate joint limits
            % link(1).qlim = [-32 120]*pi/180;
            % link(2).qlim = [-110 35]*pi/180;
            % link(3).qlim = [-180 150]*pi/180;
            % link(4).qlim = [-50 350]*pi/180;
            % link(5).qlim = [-100 65]*pi/180;
            % link(6).qlim = [-350 -50]*pi/180;
            % link(7).qlim = [-360 360]*pi/180;
            % 
            % link(2).offset = pi/2;
            % link(3).offset = -pi/2;
            % link(5).offset = -pi/2;

                 
            % Create the robot model
            self.model = SerialLink(link,'name',self.name);
        end
     
    end
end
    
  


